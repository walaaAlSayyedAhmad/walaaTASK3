﻿namespace WebApplication55
{
    public class student
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int Age { get; set; }

        public string City { get; set; } = string.Empty;
    }
}
