﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication55.interfaces;


namespace WebApplication55.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {

        private Interface _studentRepo;
        public List<student> students = new List<student>()
            {
                 new student{Id=1,  Name="walaa",Age=23,City="Jenin"},

                new student{Id=2,  Name="walaa22",Age=25,City="Ramallah"},

            };
        public ValuesController(Interface studentRepo)
        {
            _studentRepo = studentRepo;
        }

        [HttpGet]
        [Route("getStudents")]
        public async Task<ActionResult<student>> GetSudents()
        {

            return Ok(students);
        }

        [HttpGet]
        [Route("getStudent")]
        public async Task<ActionResult<student>> GetSudent(int id)
        {
            var student = students.Find(x => x.Id == id);
            if (student == null)
                return
                    BadRequest("No students found");
            return Ok(student);
        }

        [HttpPost]
        [Route("addStudent")]
        public async Task<ActionResult<student>> Addsudent(student request)
        {
            students.Add(request);
            return Ok(students);
        }

        [HttpPut]
        [Route("updateStudent")]
        public async Task<ActionResult<student>> updatesudent(student request)
        {
            var student = students.Find(x => x.Id == request.Id);
            if (student == null)
                return BadRequest("No students found");
            student.Name = request.Name;
            student.Age = request.Age;
            student.City = request.City;
            return Ok(students);
        }

        [HttpDelete]
        [Route("deleteStudent")]
        public async Task<ActionResult<student>> Deletesudent(int id)
        {
            var student = students.Find(x => x.Id == id);
            if (student == null)
                return
                    BadRequest("No students found");

            students.Remove(student);
            return Ok(student);

        }
    }
}