﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Xml.Linq;

namespace WebApplication55.interfaces
{
    public interface Interface
    {
        List<student> Get();
        student Get(int id);
        public void Addstudent(student student);
        student updatestudent(student request);
        public void Delete(int id);
    }

    public class studentRepo : Interface
    {

        public List<student> students = new List<student>()
            {
                 new student{Id=1,  Name="walaa",Age=23,City="Jenin"},

                new student{Id=2,  Name="walaa22",Age=25,City="Ramallah"},

            };
        private object Student;

        public void Addstudent(student student)
        {
            students.Add(student);
        }

        public void Delete(int id)
        {
            students.Remove((student)Student);

        }

        public List<student> Get()
        {
            return students;
        }

        public student Get(int Id)
        {
            return students.FirstOrDefault(f => f.Id == Id);
        }

        public student updatestudent(student request)
        {
            var student = students.Find(p => p.Id == request.Id);

            student.Id = request.Id;
            student.Name = request.Name;
            student.Age = request.Age;
            student.City = request.City;
            return student;

        }

        student Interface.updatestudent(student request)
        {
            throw new NotImplementedException();
        }
    }
}

